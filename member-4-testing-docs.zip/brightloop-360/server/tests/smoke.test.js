// Start the API first, then run: npm test --prefix server
import test from 'node:test';
import assert from 'node:assert/strict';
const BASE_URL = process.env.API_BASE_URL || 'http://localhost:4000';

test('health endpoint reports API is running', async () => {
  const response = await fetch(`${BASE_URL}/api/health`);
  assert.equal(response.status, 200);
  const body = await response.json();
  assert.equal(body.ok, true);
  assert.equal(body.app, 'Brightloop 360');
});
test('protected profile endpoint rejects requests without a token', async () => {
  const response = await fetch(`${BASE_URL}/api/me`);
  assert.equal(response.status, 401);
});
