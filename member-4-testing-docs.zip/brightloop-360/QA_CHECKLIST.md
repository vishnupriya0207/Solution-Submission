# Brightloop 360 — QA checklist

## Accounts
- [ ] Admin can sign in and access admin screens.
- [ ] Staff can sign in and perform permitted actions.
- [ ] Customer sees only their own records.
- [ ] Invalid login is rejected.

## Core workflows
- [ ] Create a customer, product and plan.
- [ ] Create a subscription and check its status.
- [ ] Generate an invoice from a subscription.
- [ ] Duplicate billing period is rejected.
- [ ] Record a partial payment and verify outstanding balance.
- [ ] Complete payment and verify invoice status becomes Paid.
- [ ] Verify tax and discount calculations.
- [ ] Check overdue invoice and dashboard figures.

## Demo
- [ ] Run from a clean install.
- [ ] Use demo data only.
- [ ] Prepare a 2–3 minute walkthrough.
- [ ] State known limitations honestly.
