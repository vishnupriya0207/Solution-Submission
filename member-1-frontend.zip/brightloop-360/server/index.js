import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { fileURLToPath } from 'url';
import path from 'path';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, 'brightloop.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
const JWT_SECRET = process.env.JWT_SECRET || 'change-this-demo-secret-before-deployment';

const schema = `
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL CHECK(role IN ('Admin','Staff','Customer')), customer_id INTEGER, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL, company TEXT, phone TEXT, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, type TEXT DEFAULT 'Service', sales_price REAL DEFAULT 0, cost_price REAL DEFAULT 0, variant TEXT, variant_extra REAL DEFAULT 0, notes TEXT);
CREATE TABLE IF NOT EXISTS plans (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, interval TEXT DEFAULT 'Monthly', price REAL DEFAULT 0, min_quantity INTEGER DEFAULT 1, available_from TEXT, available_to TEXT, auto_close INTEGER DEFAULT 0, status TEXT DEFAULT 'Active');
CREATE TABLE IF NOT EXISTS quotations (id INTEGER PRIMARY KEY AUTOINCREMENT, quote_no TEXT UNIQUE, customer_id INTEGER, product_id INTEGER, quantity INTEGER DEFAULT 1, amount REAL DEFAULT 0, valid_until TEXT, status TEXT DEFAULT 'Draft', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS subscriptions (id INTEGER PRIMARY KEY AUTOINCREMENT, subscription_no TEXT UNIQUE, customer_id INTEGER, plan_id INTEGER, product_id INTEGER, quantity INTEGER DEFAULT 1, unit_price REAL DEFAULT 0, start_date TEXT, end_date TEXT, status TEXT DEFAULT 'Draft', next_billing TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS taxes (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, rate REAL DEFAULT 0, active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS discounts (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, kind TEXT DEFAULT 'Percentage', value REAL DEFAULT 0, min_quantity INTEGER DEFAULT 1, start_date TEXT, end_date TEXT, usage_limit INTEGER DEFAULT 0, scope TEXT DEFAULT 'Subscription', active INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS invoices (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT UNIQUE, customer_id INTEGER, subscription_id INTEGER, period_start TEXT, period_end TEXT, subtotal REAL DEFAULT 0, tax REAL DEFAULT 0, discount REAL DEFAULT 0, total REAL DEFAULT 0, paid REAL DEFAULT 0, due_date TEXT, status TEXT DEFAULT 'Draft', created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(subscription_id, period_start));
CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, method TEXT DEFAULT 'UPI', amount REAL DEFAULT 0, paid_on TEXT, note TEXT);
`;
db.exec(schema);

const count = (table) => db.prepare(`SELECT COUNT(*) n FROM ${table}`).get().n;
if (count('customers') === 0) {
  const addCustomer = db.prepare('INSERT INTO customers(name,email,company,phone) VALUES(?,?,?,?)');
  addCustomer.run('Aarav Menon','aarav@example.com','Northstar Labs','9876543210');
  addCustomer.run('Diya Thomas','diya@example.com','PixelCraft Studio','9876501234');
  addCustomer.run('Rahul Nair','rahul@example.com','CloudNine Tech','9895012345');
}
if (count('products') === 0) {
  db.prepare('INSERT INTO products(name,type,sales_price,cost_price,variant,variant_extra,notes) VALUES(?,?,?,?,?,?,?)').run('Odoo Implementation','Service',12500,7200,'Enterprise',560,'Implementation and support package');
  db.prepare('INSERT INTO products(name,type,sales_price,cost_price,variant,variant_extra,notes) VALUES(?,?,?,?,?,?,?)').run('Cloud Backup','Service',2400,900,'Standard',0,'Monthly cloud backup');
  db.prepare('INSERT INTO products(name,type,sales_price,cost_price,variant,variant_extra,notes) VALUES(?,?,?,?,?,?,?)').run('Analytics Suite','Software',5500,1800,'Pro',0,'Business analytics tools');
}
if (count('plans') === 0) {
  const p = db.prepare('INSERT INTO plans(name,interval,price,min_quantity) VALUES(?,?,?,?)');
  p.run('Monthly Essential','Monthly',2400,1); p.run('Annual Growth','Yearly',24000,1); p.run('Weekly Starter','Weekly',700,1);
}
if (count('taxes') === 0) db.prepare('INSERT INTO taxes(name,rate) VALUES(?,?)').run('GST',18);
if (count('users') === 0) {
  const hash = bcrypt.hashSync('Brightloop@123', 10);
  const add = db.prepare('INSERT INTO users(name,email,password_hash,role,customer_id) VALUES(?,?,?,?,?)');
  add.run('Brightloop Admin','admin@brightloop.demo',hash,'Admin',null);
  add.run('Operations Staff','staff@brightloop.demo',hash,'Staff',null);
  add.run('Aarav Menon','aarav@example.com',hash,'Customer',1);
}
if (count('subscriptions') === 0) {
  db.prepare(`INSERT INTO subscriptions(subscription_no,customer_id,plan_id,product_id,quantity,unit_price,start_date,end_date,status,next_billing) VALUES('BL-SUB-1001',1,1,1,1,13060,date('now','-20 day'),date('now','+10 month'),'Active',date('now','+10 day'))`).run();
  db.prepare(`INSERT INTO subscriptions(subscription_no,customer_id,plan_id,product_id,quantity,unit_price,start_date,end_date,status,next_billing) VALUES('BL-SUB-1002',2,2,2,2,2400,date('now','-60 day'),date('now','+10 month'),'Active',date('now','+5 day'))`).run();
}
if (count('invoices') === 0) {
  db.prepare(`INSERT INTO invoices(invoice_no,customer_id,subscription_id,period_start,period_end,subtotal,tax,discount,total,paid,due_date,status) VALUES('BL-INV-1001',1,1,date('now','-20 day'),date('now','+10 day'),13060,2350.8,0,15410.8,15410.8,date('now','+10 day'),'Paid')`).run();
  db.prepare(`INSERT INTO invoices(invoice_no,customer_id,subscription_id,period_start,period_end,subtotal,tax,discount,total,paid,due_date,status) VALUES('BL-INV-1002',2,2,date('now','-30 day'),date('now'),4800,864,0,5664,2000,date('now','-5 day'),'Confirmed')`).run();
}

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());
const tableMap = {
  customers: ['customers', ['name','email','company','phone','status']],
  products: ['products', ['name','type','sales_price','cost_price','variant','variant_extra','notes']],
  plans: ['plans', ['name','interval','price','min_quantity','available_from','available_to','auto_close','status']],
  quotations: ['quotations', ['customer_id','product_id','quantity','amount','valid_until','status']],
  subscriptions: ['subscriptions', ['customer_id','plan_id','product_id','quantity','unit_price','start_date','end_date','status','next_billing']],
  invoices: ['invoices', ['customer_id','subscription_id','period_start','period_end','subtotal','tax','discount','total','paid','due_date','status']],
  payments: ['payments', ['invoice_id','method','amount','paid_on','note']],
  discounts: ['discounts', ['name','kind','value','min_quantity','start_date','end_date','usage_limit','scope','active']],
  taxes: ['taxes', ['name','rate','active']]
};
function auth(req,res,next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i,'');
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({error:'Please sign in again.'}); }
}
function allow(...roles) { return (req,res,next) => roles.includes(req.user.role) ? next() : res.status(403).json({error:'You do not have permission for this action.'}); }
app.get('/api/health', (_req,res) => res.json({ok:true,app:'Brightloop 360'}));
app.post('/api/auth/login', (req,res) => {
  const {email,password} = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE lower(email)=lower(?)').get(email || '');
  if (!user || !bcrypt.compareSync(password || '', user.password_hash)) return res.status(401).json({error:'Invalid email or password.'});
  const token = jwt.sign({id:user.id,name:user.name,email:user.email,role:user.role,customer_id:user.customer_id}, JWT_SECRET, {expiresIn:'12h'});
  res.json({token,user:{id:user.id,name:user.name,email:user.email,role:user.role}});
});
app.get('/api/me', auth, (req,res) => res.json(req.user));
app.get('/api/dashboard', auth, (req,res) => {
  const customerFilter = req.user.role === 'Customer' ? ' AND customer_id = ?' : '';
  const args = req.user.role === 'Customer' ? [req.user.customer_id] : [];
  const scalar = (sql) => db.prepare(sql).get(...args).n;
  const subWhere = req.user.role === 'Customer' ? 'WHERE customer_id = ?' : '';
  const invWhere = req.user.role === 'Customer' ? 'WHERE customer_id = ?' : '';
  const active = db.prepare(`SELECT COUNT(*) n FROM subscriptions ${subWhere} ${subWhere ? "AND" : "WHERE"} status='Active'`).get(...args).n;
  const revenue = db.prepare(`SELECT COALESCE(SUM(paid),0) n FROM invoices ${invWhere}`).get(...args).n;
  const outstanding = db.prepare(`SELECT COALESCE(SUM(total-paid),0) n FROM invoices ${invWhere}`).get(...args).n;
  const overdue = db.prepare(`SELECT COUNT(*) n FROM invoices ${invWhere ? invWhere+' AND' : 'WHERE'} date(due_date)<date('now') AND status!='Paid'`).get(...args).n;
  const recent = db.prepare(`SELECT i.*, c.name customer_name FROM invoices i LEFT JOIN customers c ON c.id=i.customer_id ${req.user.role==='Customer'?'WHERE i.customer_id=?':''} ORDER BY i.id DESC LIMIT 6`).all(...args);
  res.json({active,revenue,outstanding,overdue,recent});
});
app.get('/api/:resource', auth, (req,res) => {
  const cfg = tableMap[req.params.resource]; if (!cfg) return res.status(404).json({error:'Unknown resource'});
  const [table] = cfg;
  let rows;
  if (req.user.role === 'Customer') {
    if (table === 'customers') rows = db.prepare('SELECT * FROM customers WHERE id=?').all(req.user.customer_id);
    else if (['subscriptions','invoices','quotations'].includes(table)) rows = db.prepare(`SELECT * FROM ${table} WHERE customer_id=? ORDER BY id DESC`).all(req.user.customer_id);
    else if (table === 'payments') rows = db.prepare('SELECT p.* FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE i.customer_id=? ORDER BY p.id DESC').all(req.user.customer_id);
    else rows = [];
  } else {
    rows = db.prepare(`SELECT * FROM ${table} ORDER BY id DESC`).all();
  }
  res.json(rows);
});
app.post('/api/:resource', auth, allow('Admin','Staff'), (req,res) => {
  const cfg = tableMap[req.params.resource]; if (!cfg) return res.status(404).json({error:'Unknown resource'});
  const [table, fields] = cfg; const data = req.body || {};
  const keys = fields.filter(k => data[k] !== undefined);
  if (!keys.length) return res.status(400).json({error:'Enter at least one field.'});
  const values = keys.map(k => data[k]);
  if (table === 'quotations') { const quote = `BL-Q-${Date.now().toString().slice(-7)}`; keys.push('quote_no'); values.push(quote); }
  if (table === 'subscriptions') { const no = `BL-SUB-${Date.now().toString().slice(-7)}`; keys.push('subscription_no'); values.push(no); }
  if (table === 'invoices') { const no = `BL-INV-${Date.now().toString().slice(-7)}`; keys.push('invoice_no'); values.push(no); }
  try {
    const result = db.prepare(`INSERT INTO ${table} (${keys.join(',')}) VALUES (${keys.map(()=>'?').join(',')})`).run(...values);
    res.status(201).json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(result.lastInsertRowid));
  } catch(e) { res.status(400).json({error:e.message.includes('UNIQUE')?'This record already exists.':e.message}); }
});
app.patch('/api/:resource/:id', auth, allow('Admin','Staff'), (req,res) => {
  const cfg = tableMap[req.params.resource]; if (!cfg) return res.status(404).json({error:'Unknown resource'});
  const [table, fields] = cfg; const keys = fields.filter(k => req.body?.[k] !== undefined);
  if (!keys.length) return res.status(400).json({error:'No changes provided.'});
  try {
    db.prepare(`UPDATE ${table} SET ${keys.map(k=>`${k}=?`).join(',')} WHERE id=?`).run(...keys.map(k=>req.body[k]), req.params.id);
    res.json(db.prepare(`SELECT * FROM ${table} WHERE id=?`).get(req.params.id));
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.delete('/api/:resource/:id', auth, allow('Admin'), (req,res) => {
  const cfg = tableMap[req.params.resource]; if (!cfg) return res.status(404).json({error:'Unknown resource'});
  try { db.prepare(`DELETE FROM ${cfg[0]} WHERE id=?`).run(req.params.id); res.json({ok:true}); }
  catch(e) { res.status(400).json({error:'Cannot delete this record because it may be linked to another record.'}); }
});
app.post('/api/invoices/generate/:subscriptionId', auth, allow('Admin','Staff'), (req,res) => {
  const sub = db.prepare('SELECT * FROM subscriptions WHERE id=?').get(req.params.subscriptionId);
  if (!sub) return res.status(404).json({error:'Subscription not found.'});
  const periodStart = sub.next_billing || new Date().toISOString().slice(0,10);
  const periodEnd = new Date(new Date(periodStart).setMonth(new Date(periodStart).getMonth()+1)).toISOString().slice(0,10);
  const exists = db.prepare('SELECT id FROM invoices WHERE subscription_id=? AND period_start=?').get(sub.id,periodStart);
  if (exists) return res.status(409).json({error:'An invoice already exists for this billing period.'});
  const subtotal = Number(sub.unit_price) * Number(sub.quantity || 1);
  const taxRate = db.prepare('SELECT COALESCE(SUM(rate),0) n FROM taxes WHERE active=1').get().n;
  const tax = subtotal * taxRate / 100; const total = subtotal + tax;
  const no = `BL-INV-${Date.now().toString().slice(-7)}`;
  try {
    const result = db.prepare(`INSERT INTO invoices(invoice_no,customer_id,subscription_id,period_start,period_end,subtotal,tax,total,due_date,status) VALUES(?,?,?,?,?,?,?,?,?,'Draft')`).run(no,sub.customer_id,sub.id,periodStart,periodEnd,subtotal,tax,total,periodStart);
    res.status(201).json(db.prepare('SELECT * FROM invoices WHERE id=?').get(result.lastInsertRowid));
  } catch(e) { res.status(400).json({error:e.message}); }
});
app.post('/api/payments/record', auth, allow('Admin','Staff'), (req,res) => {
  const {invoice_id,method,amount,paid_on,note} = req.body || {};
  const invoice = db.prepare('SELECT * FROM invoices WHERE id=?').get(invoice_id);
  if (!invoice) return res.status(404).json({error:'Invoice not found.'});
  const value = Number(amount);
  if (!(value > 0) || value > invoice.total - invoice.paid + 0.001) return res.status(400).json({error:'Enter a valid amount not exceeding the outstanding balance.'});
  const tx = db.transaction(() => {
    db.prepare('INSERT INTO payments(invoice_id,method,amount,paid_on,note) VALUES(?,?,?,?,?)').run(invoice_id,method || 'UPI',value,paid_on || new Date().toISOString().slice(0,10),note || '');
    const paid = invoice.paid + value; const status = paid >= invoice.total ? 'Paid' : 'Confirmed';
    db.prepare('UPDATE invoices SET paid=?,status=? WHERE id=?').run(paid,status,invoice_id);
  });
  tx(); res.status(201).json({ok:true});
});
app.post('/api/auth/register', (req,res) => {
  const {name,email,password} = req.body || {};
  if (!name || !email || !password || password.length <= 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/[^A-Za-z0-9]/.test(password)) return res.status(400).json({error:'Use a password longer than 8 characters with uppercase, lowercase and a special character.'});
  try { const hash=bcrypt.hashSync(password,10); db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'Customer')").run(name,email,hash); res.status(201).json({ok:true}); }
  catch { res.status(400).json({error:'That email is already registered.'}); }
});
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Brightloop API running at http://localhost:${PORT}`));
